import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class DevelopersScreen extends StatelessWidget {
  // A list of developer contacts
  final List<Map<String, String>> developers = [
    {'name': 'Kushal Khadgi', 'phone': '7058065928'},
    {'name': 'Nakul Wanjari', 'phone': '9356304607'},
    {'name': 'Abhishek Wasekar', 'phone': '7720986890'},
  ];

  // Method to launch the dialer
  void _launchDialer(String phoneNumber) async {
    final Uri phoneUri = Uri(scheme: 'tel', path: phoneNumber);
    if (await canLaunchUrl(phoneUri)) {
      await launchUrl(phoneUri);
    } else {
      throw 'Could not launch $phoneNumber';
    }
  }

  // Method to launch WhatsApp
  void _launchWhatsApp(String phoneNumber) async {
    String whatsappUrl = 'https://wa.me/${phoneNumber.replaceAll('+', '')}';
    if (await canLaunchUrl(Uri.parse(whatsappUrl))) {
      await launchUrl(Uri.parse(whatsappUrl));
    } else {
      throw 'Could not launch WhatsApp for $phoneNumber';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor:  const Color.fromARGB(255, 255, 180, 68),
        title: Text('Developers Contact'),
      ),
      body: ListView.builder(
        itemCount: developers.length,
        itemBuilder: (context, index) {
          return Padding(
            padding: const EdgeInsets.all(8.0),
            child: Card(
              child: Column(
                children: [
                  ListTile(
                    title: Text(
                      '${developers[index]['name']!}',
                      style: TextStyle(fontSize: 16),
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        // WhatsApp Icon Button
                        IconButton(
                          icon: Icon(Icons.wechat_outlined),
                          onPressed: () => _launchWhatsApp(developers[index]['phone']!),
                        ),
                        // Call Icon Button
                        IconButton(
                          icon: Icon(Icons.call_outlined),
                          onPressed: () => _launchDialer(developers[index]['phone']!),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
